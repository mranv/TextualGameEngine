#include "GameManager.hpp"

int main()
{
	GameManager GM;
}
